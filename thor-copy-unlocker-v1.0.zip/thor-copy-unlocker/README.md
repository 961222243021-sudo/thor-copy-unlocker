# ⚡ Thor – Copy & Paste Unlocker
Made by **Shyam**. Version 1.0.0

Strikes down websites' copy / cut / paste / right-click / text-selection locks, and includes a simple screen recorder.

## Install (Chrome / Edge / Brave)
1. Unzip, keep the folder somewhere permanent.
2. Open `chrome://extensions`, enable **Developer mode**.
3. **Load unpacked** → choose the `thor-copy-unlocker` folder.

## Features
- Unlocks copy / cut / paste / right-click / text selection (per-site on/off toggle in the popup).
- **Screen recorder**: popup → "Record screen" opens a recorder tab (screen / window / tab via the browser's own picker, optional audio and mic). After stopping: preview, download the video, or copy the current frame as an image to paste into ChatGPT. (Browsers can't copy a whole video to the clipboard.)

## How it works
- `main-world.js` runs in the page's own JS context and neutralises `preventDefault()` for copy/cut/paste/contextmenu/selectstart/dragstart and Ctrl/Cmd+C/V/X/A/P.
- `content.js` forces `user-select:text`, clears inline `on*` blockers, and uses a MutationObserver (no polling).
- `recorder.html` / `recorder.js`: MediaRecorder-based recorder.
